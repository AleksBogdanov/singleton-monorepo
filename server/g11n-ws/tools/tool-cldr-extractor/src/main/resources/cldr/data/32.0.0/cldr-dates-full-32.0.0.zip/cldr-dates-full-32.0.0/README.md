# cldr-dates-full

This repository provides the a portion of the JSON distribution of CLDR locale data
for internationalization.

Refer to the README at https://github.com/unicode-cldr/cldr-json for complete details.
